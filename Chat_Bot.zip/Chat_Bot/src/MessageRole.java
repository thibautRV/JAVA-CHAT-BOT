public enum MessageRole {
    USER,
    CHATBOT
}